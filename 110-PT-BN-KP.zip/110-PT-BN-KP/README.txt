﻿110-PT-BN Corpus

Version 1.0 2011
Created by Luis Marujo (lmarujo@cs.cmu.edu)

If you publish research based on these data, please cite the following
paper:

Luis Marujo, Márcio Viveiros, João P. Neto, Keyphrase Cloud Generation of Broadcast News, In proceeding of Interspeech 2011: 12th Annual Conference of the International Speech Communication Association, ISCA, Florence, Italy, August 2011

http://www.inesc-id.pt/ficheiros/publicacoes/7588.pdf

@inproceedings{Marujo_Interspeech_2011,
   author = {Luis Marujo and M\'{a}rcio Viveiros and Jo\~{a}o P. Neto},
   title = {{Keyphrase Cloud Generation of Broadcast News}},
   booktitle = {Interspeech 2011},
   publisher = {ISCA},
   location = {Florence, Italy},
   year = {2011},
   month = {September}
}

More details about the corpus can be found in the paper.
