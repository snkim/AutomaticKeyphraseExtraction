There are three types of files:

.abstr: Contains the title and the abstract. When inspecting
a file, it should be clear how the title is separated from the
abstract. Note, however, that the title is sometimes longer 
than one line.

.contr: Contains the controlled manually assigned keywords,
separated with semicolon.

.uncontr: Contains the uncontrolled manually assigned keywords,
separated with semicolon. These are the keywords that I used
for my experiments.


For questions, please contact: 

     /Anette (hulth@dsv.su.se)


http://people.dsv.su.se/~hulth/Keyword_data/

